<?php
class MoneyValidation {
    // 入出金の金額入力値をチェックするクラスメソッド
    public static function check($money) {
        if (strcmp($money, intval($money)) !== 0) {
            echo '金額は 0 以上の整数で入力してください。' . PHP_EOL;
            return false;
        }
        
        return true;
    }
}

?>