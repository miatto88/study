<?php
require_once('index.php');  // Atm::INPUTEXISTSを使用する為の読み込み

class MenuValidation {
    // 処理選択の入力値をチェックするクラスメソッド
    public static function check($input) {
        if (array_key_exists($input, Atm::INPUTEXISTS)) {
            return true;
        }
        
        echo '0～3の数字で入力してください。' . PHP_EOL;
        return false;
    }
}

?>