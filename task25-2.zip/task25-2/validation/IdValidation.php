<?php
require_once('validation/BaseValidation.php');


class IdValidation extends BaseValidation {
    // 処理選択の入力値をチェックするクラスメソッド
    public function check($input) {
        if (!is_numeric($input)) {
            $this->setErrorMessages("id", "数字で入力してください");
            return false;
        }

        if (strlen($input) !== 3) {
            $this->setErrorMessages("id", "3ケタの数字で入力してください");
            return false;
        }

        if (!array_key_exists($input, Item::$itemList)) {
            $this->setErrorMessages("id", "指定のIDが存在しません");
            return false;
        }
        
        return true;
    }
}

?>