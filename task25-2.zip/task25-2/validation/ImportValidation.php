<?php
require_once('validation/BaseValidation.php');


class ImportValidation extends BaseValidation {
    // インポートするファイルの行頭ラベルをチェックするクラスメソッド
    public function check($label) {
        $head = "商品名,JANコード";
        if ($label === $head) {
            return true;
        }
        
        $this->setErrorMessages("import", "csvファイルの形式が正しくありません");
        return false;
    }
}

?>